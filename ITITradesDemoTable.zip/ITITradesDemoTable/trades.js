$(document).ready(function() {
    $('#trade').DataTable();
} );